package fiveC;

import java.util.List;

public class Team {
	private int code;
	private List<Player> listPlayers;
	public Team() {
		code = 0;
	}
	
	public void addPlayer(Player player) {
		listPlayers.add(player);
	}
}
