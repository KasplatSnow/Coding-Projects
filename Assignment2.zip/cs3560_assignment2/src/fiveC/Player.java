package fiveC;

public class Player {
	private String name;
	private boolean expert;
	
	public Player(String name, boolean expert) {
		this.name = name;
		this.expert = expert;
	}
}
