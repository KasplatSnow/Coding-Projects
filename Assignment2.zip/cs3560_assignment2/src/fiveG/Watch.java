package fiveG;

public class Watch{
	private int rating;
	private Movie movie;
	private Person person;
	public Watch(Movie movie, Person person, int rating){
		this.movie = movie;
		this.person = person;
		this.rating = rating;
	}
}
