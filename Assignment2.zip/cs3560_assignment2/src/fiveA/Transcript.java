package fiveA;

public class Transcript {
	private String course;
	private double grade;
	
	public Transcript(String course, double grade) {
		this.course = course;
		this.grade = grade;
	}
}
