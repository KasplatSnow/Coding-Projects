package fiveF;

public interface SaleableItem{
	public void sellCopy();
	/*
	 * An implementing class must print the message "Selling a <specific item here">
	 */
}
