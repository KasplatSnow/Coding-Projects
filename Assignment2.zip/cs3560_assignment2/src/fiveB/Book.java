package fiveB;

public class Book {
	private String name;
	private String author;
	private Course course;
	
	public Book() {
		name = null;
		author = null;
		course = null;
	}
}
