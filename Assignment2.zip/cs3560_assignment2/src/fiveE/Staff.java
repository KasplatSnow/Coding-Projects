package fiveE;

public class Staff extends Employee{
	private int role;
	
	public Staff(String name, Integer hours, int role) {
		super(name, hours);
		this.role = role;
	}
}
