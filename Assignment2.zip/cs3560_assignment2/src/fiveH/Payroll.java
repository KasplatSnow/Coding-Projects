package fiveH;

public class Payroll {
	
	public Payroll() {	
	}
	public static void processPayments(Worker worker) {
		System.out.println("Payment processed for worder " + worker.getName());
	}
}
