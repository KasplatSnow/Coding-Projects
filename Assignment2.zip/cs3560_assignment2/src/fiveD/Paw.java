package fiveD;

public class Paw {
	private int position;
	private Dog dog;
	public Paw(int position, Dog dog) {
		this.position = position;
		this.dog = dog;
	}
}
