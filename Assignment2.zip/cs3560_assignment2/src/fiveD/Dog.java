package fiveD;

import java.util.List;

public class Dog {
	private String breed;
	private String name;
	private List<Paw> listPaws;
	public Dog() {
		breed = null;
		name = null;
	}
}
